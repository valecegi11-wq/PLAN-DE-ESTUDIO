
import React, { useState, useEffect } from "react";

const initialSubjects = [
  // 1er Año - 1er Cuatrimestre
  { id: "A1", name: "Matemática I", correlatives: [], year: 1, term: 1 },
  { id: "A2", name: "Química General", correlatives: [], year: 1, term: 1 },
  { id: "A3", name: "Introducción a la Biotecnología", correlatives: [], year: 1, term: 1 },
  { id: "A4", name: "Biología Celular", correlatives: [], year: 1, term: 1 },

  // 1er Año - 2do Cuatrimestre
  { id: "B1", name: "Matemática II", correlatives: ["A1"], year: 1, term: 2 },
  { id: "B2", name: "Física I", correlatives: ["A1"], year: 1, term: 2 },
  { id: "B3", name: "Química Inorgánica", correlatives: ["A2"], year: 1, term: 2 },
  { id: "B4", name: "Introducción a la Programación", correlatives: [], year: 1, term: 2 },

  // 2do Año - 1er Cuatrimestre
  { id: "C1", name: "Física II", correlatives: ["B2"], year: 2, term: 1 },
  { id: "C2", name: "Química Orgánica I", correlatives: ["B3"], year: 2, term: 1 },
  { id: "C3", name: "Probabilidad y Estadística", correlatives: ["B1"], year: 2, term: 1 },
  { id: "C4", name: "Biología Molecular", correlatives: ["A4"], year: 2, term: 1 },

  // 2do Año - 2do Cuatrimestre
  { id: "D1", name: "Química Orgánica II", correlatives: ["C2"], year: 2, term: 2 },
  { id: "D2", name: "Química Analítica", correlatives: ["B3"], year: 2, term: 2 },
  { id: "D3", name: "Microbiología General", correlatives: ["C4"], year: 2, term: 2 },
  { id: "D4", name: "Bioquímica", correlatives: ["C4", "C2"], year: 2, term: 2 },

  // 3er Año - 1er Cuatrimestre
  { id: "E1", name: "Ingeniería Genética", correlatives: ["D3", "D4"], year: 3, term: 1 },
  { id: "E2", name: "Fisiología", correlatives: ["D4"], year: 3, term: 1 },
  { id: "E3", name: "Inmunología", correlatives: ["D3", "D4"], year: 3, term: 1 },
  { id: "E4", name: "Físicoquímica", correlatives: ["C1", "D1"], year: 3, term: 1 },

  // 3er Año - 2do Cuatrimestre
  { id: "F1", name: "Biología de Sistemas", correlatives: ["E1"], year: 3, term: 2 },
  { id: "F2", name: "Técnicas Instrumentales", correlatives: ["D2", "E4"], year: 3, term: 2 },
  { id: "F3", name: "Biotecnología Vegetal", correlatives: ["E1"], year: 3, term: 2 },
  { id: "F4", name: "Biotecnología Animal", correlatives: ["E1"], year: 3, term: 2 },

  // 4to Año - 1er Cuatrimestre
  { id: "G1", name: "Ingeniería Bioquímica", correlatives: ["E4", "F2"], year: 4, term: 1 },
  { id: "G2", name: "Biotecnología Microbiana", correlatives: ["E1"], year: 4, term: 1 },
  { id: "G3", name: "Genómica y Proteómica", correlatives: ["E1", "F1"], year: 4, term: 1 },
  { id: "G4", name: "Bioinformática", correlatives: ["F1"], year: 4, term: 1 },

  // 4to Año - 2do Cuatrimestre
  { id: "H1", name: "Biotecnología Industrial", correlatives: ["G1"], year: 4, term: 2 },
  { id: "H2", name: "Biotecnología Ambiental", correlatives: ["G1"], year: 4, term: 2 },
  { id: "H3", name: "Bioprocesos", correlatives: ["G1"], year: 4, term: 2 },
  { id: "H4", name: "Ética y Legislación", correlatives: [], year: 4, term: 2 },

  // 5to Año - 1er Cuatrimestre
  { id: "I1", name: "Proyecto Integrador I", correlatives: ["H1", "H2", "H3"], year: 5, term: 1 },
  { id: "I2", name: "Optativa I", correlatives: [], year: 5, term: 1 },
  { id: "I3", name: "Optativa II", correlatives: [], year: 5, term: 1 },

  // 5to Año - 2do Cuatrimestre
  { id: "J1", name: "Proyecto Integrador II", correlatives: ["I1"], year: 5, term: 2 },
  { id: "J2", name: "Práctica Profesional Supervisada", correlatives: ["I1"], year: 5, term: 2 },
];

function groupByYearTerm(list) {
  const grouped = {};
  list.forEach((s) => {
    const key = `${s.year}-${s.term}`;
    if (!grouped[key]) grouped[key] = [];
    grouped[key].push(s);
  });
  return grouped;
}

export default function App() {
  const [subjects, setSubjects] = useState([]);

  useEffect(() => {
    const raw = localStorage.getItem("planSubjects_v1");
    if (raw) setSubjects(JSON.parse(raw));
    else {
      // initialize with passed:false
      setSubjects(initialSubjects.map((s) => ({ ...s, passed: false })));
    }
  }, []);

  useEffect(() => {
    if (subjects.length) localStorage.setItem("planSubjects_v1", JSON.stringify(subjects));
  }, [subjects]);

  const togglePassed = (id) => {
    setSubjects((prev) => prev.map((s) => (s.id === id ? { ...s, passed: !s.passed } : s)));
  };

  const canTake = (subject) =>
    subject.correlatives.every((c) => subjects.find((s) => s.id === c && s.passed));

  const total = subjects.length;
  const approved = subjects.filter((s) => s.passed).length;

  const grouped = groupByYearTerm(subjects);

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-6xl mx-auto">
        <header className="mb-6">
          <h1 className="text-3xl font-bold">Plan de Estudio - Lic. en Biotecnología</h1>
          <p className="text-sm text-gray-600">Marcar materias aprobadas para que se desbloqueen las correlativas.</p>

          <div className="mt-4 flex items-center gap-4">
            <div className="px-4 py-2 bg-white rounded shadow">
              <div className="text-xs text-gray-500">Aprobadas</div>
              <div className="text-lg font-semibold">{approved} / {total}</div>
            </div>
            <div className="px-4 py-2 bg-white rounded shadow">
              <div className="text-xs text-gray-500">Pendientes</div>
              <div className="text-lg font-semibold">{total - approved}</div>
            </div>
            <div className="ml-auto">
              <button
                className="px-3 py-1 bg-red-100 rounded"
                onClick={() => {
                  if (!confirm("¿Querés restablecer todo el plan (quitar aprobadas)?")) return;
                  setSubjects(initialSubjects.map((s) => ({ ...s, passed: false })));
                  localStorage.removeItem("planSubjects_v1");
                }}
              >
                Resetear progreso
              </button>
            </div>
          </div>
        </header>

        <main>
          {Object.keys(grouped)
            .sort((a, b) => {
              const [ya, ta] = a.split("-").map(Number);
              const [yb, tb] = b.split("-").map(Number);
              if (ya !== yb) return ya - yb;
              return ta - tb;
            })
            .map((key) => {
              const [year, term] = key.split("-");
              const list = grouped[key];
              return (
                <section key={key} className="mb-8">
                  <h2 className="text-xl font-semibold mb-3">{year}º Año — {term}º Cuatrimestre</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                    {list.map((s) => {
                      const unlocked = canTake(s);
                      const bg = s.passed ? "bg-green-200" : unlocked ? "bg-white" : "bg-gray-200";
                      return (
                        <div
                          key={s.id}
                          className={`${bg} p-4 rounded-lg shadow cursor-pointer border ${s.passed ? "border-green-400" : unlocked ? "border-yellow-300" : "border-gray-300"}`}
                          onClick={() => unlocked && togglePassed(s.id)}
                          title={s.correlatives.length ? "Correlativas: " + s.correlatives.join(", ") : "Sin correlativas"}
                        >
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-medium">{s.name}</h3>
                              <p className="text-xs text-gray-600">{s.id}</p>
                              <p className="text-xs mt-2 text-gray-700">{s.correlatives.length ? "Correlativas: " + s.correlatives.join(", ") : "Sin correlativas"}</p>
                            </div>
                            <div className="text-right">
                              <div className="text-sm font-semibold">{s.passed ? "APROBADA" : unlocked ? "DISPONIBLE" : "BLOQUEADA"}</div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </section>
              );
            })}
        </main>
      </div>
    </div>
  );
}
