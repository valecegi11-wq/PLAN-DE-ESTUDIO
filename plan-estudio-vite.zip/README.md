# Plan de Estudio - Biotecnología (Vite + React)

Proyecto minimal para visualizar y marcar materias aprobadas.  
Está pensado para desplegar en Vercel o correr localmente con Vite.

## Instrucciones (local)
1. Instalar Node.js (LTS).
2. Abrir terminal en la carpeta del proyecto.
3. Ejecutar:
   ```
   npm install
   npm run dev
   ```
4. Abrir el link que aparece (ej: http://localhost:5173).

## Deploy en Vercel
1. Crear un repo en GitHub y subir todo el contenido del zip.
2. En Vercel, seleccionar "New Project" y conectar el repo.
3. Vercel detecta Vite y hace deploy automático. Te dará un link público.

> Nota: para simplificar, el proyecto usa Tailwind vía CDN en `index.html` (rápido para prototipo). Si querés un build con Tailwind integrado, lo preparo también.

